# 小乐收集 1.0.3

在 chrome://extensions 开启开发者模式，分别加载 extensions/video-collector 和 extensions/comment-assistant 两个包含 manifest.json 的目录。

自动跳过纯表情、贴纸、图片占位和纯符号评论；带表情的文字评论原样保留。采集上限只计算文字评论，刷新恢复和导出也应用过滤。

详细操作见两个工具的 README.md。飞书与百炼请填写自己的配置。
