# 小乐收集 · 两个工具组合包 1.0.2

打开 Chrome 的 `chrome://extensions`，开启开发者模式，分别加载以下两个包含 manifest.json 的目录：

- `extensions/video-collector`：抖音/B站视频、JSON 导出、自己的飞书同步与百炼逐字稿。
- `extensions/comment-assistant`：抖音主评论自动采集到末尾，上限 100000，刷新续采、排序与 CSV 导出。

详细操作见各工具目录的 README.md。飞书目标、授权与百炼 API Key 需要填写你自己的；公开包均为空配置。采集仅限网页可加载的内容，平台登录或验证需要先在网页完成。

本包是可加载的发布产物；完整源码和测试见 https://github.com/jl2536153560-dot/daily-toolbox/tree/main/extensions/xiaole-collector 。
